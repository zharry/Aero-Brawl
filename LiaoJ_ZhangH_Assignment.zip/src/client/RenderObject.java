package client;

public class RenderObject {
	public int displayList;
	public ObjLoader.Material material;
	public int diffuseTexture = -1;
}
