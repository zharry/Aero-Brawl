package client;

import java.util.ArrayList;

public class RenderObjectList {
	public ArrayList<RenderObject> renderObjects;
	public RenderObjectList(ArrayList<RenderObject> renderObjects) {
		this.renderObjects = renderObjects;
	}
}
