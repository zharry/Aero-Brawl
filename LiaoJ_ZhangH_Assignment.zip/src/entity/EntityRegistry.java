package entity;

public class EntityRegistry {

	public static final int
			REGISTRY_EntityPlayer = 1;
}
