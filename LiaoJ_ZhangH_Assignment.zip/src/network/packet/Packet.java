package network.packet;

import java.io.Serializable;

public class Packet implements Serializable {

}
