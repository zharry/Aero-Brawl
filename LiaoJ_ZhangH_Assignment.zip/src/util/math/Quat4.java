package util.math;

public class Quat4 {
	public double w, x, y, z;

	public Quat4() {
	}

	public Quat4(double w, double x, double y, double z) {
		this.w = w;
		this.x = x;
		this.y = y;
		this.z = z;
	}
}
