package world;

public class WorldClient extends World {
	public WorldClient() {
		super(true);
	}
}
