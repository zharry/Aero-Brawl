package world;

public class WorldServer extends World {
	public WorldServer() {
		super(false);
	}
}
